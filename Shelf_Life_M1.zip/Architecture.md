# Architecture — Shelf Life (M1: Core Loop Vertical Slice)

Shelf Life is organized into strict layers so that game logic stays testable without the Unity Editor, and so that later milestones (economy depth, employees, theft, delivery, warehousing, multiplayer) can be added by *extending* existing systems rather than rewriting them.

## Layers

```
Data layer        ScriptableObjects + serializable save schemas (content & persisted state)
      |
Systems layer     Pure C#, no MonoBehaviour, unit-testable without an open Editor
      |
Gameplay layer    MonoBehaviours living on scene objects; call into Systems, never
                  re-implement logic that belongs there
      |
UI layer          uGUI panels, one per feature area, calling into Systems/Gameplay
```

### Data layer

- **`ProductData.cs`** (M1) — ScriptableObject defining a purchasable item: name, icon, category, wholesale cost, suggested price, shelf stack size.
- **`CustomerProfileData.cs`** (M1) — ScriptableObject archetype profile: patience, budget sensitivity, list adherence, browse-time and item-count ranges.
- **`StoreStateData.cs`** (M1) — Plain serializable save schema (schemaVersion, dayNumber, cashOnHand, stock, prices).

### Systems layer

Everything in this layer has zero Unity-engine dependencies beyond basic types, which is what makes it verifiable via Unity's EditMode test runner (or plain `dotnet test`) without a running scene.

- **`InventorySystem.cs`** (M1) — Pure C# stock ledger: Add/Remove/GetStock backed by a Dictionary<ProductData,int>.
- **`PricingModel.cs`** (M1) — Pure functions for suggested margin and projected sell-through per product.
- **`DemandModel.cs`** (M1) — Bounded random-walk wholesale price fluctuation, seeded for reproducible tests.
- **`CheckoutStateMachine.cs`** (M1) — Idle→Scanning→Payment→Complete state machine; scan, submit payment, change/bag-bonus math.
- **`SaveLoadService.cs`** (M1) — System.Text.Json-based Save/Load with a schemaVersion migration switch (stubbed for v1).

### Gameplay layer

- **`PlayerController.cs`** (M1) — CharacterController-based movement driven by PlayerControls.inputactions (Move/Look/Interact).
- **`ShelfSlot.cs`** (M1) — Transform anchor holding one product + count; TryPlace fails cleanly on a mismatched product.
- **`ShelfStockingInteractor.cs`** (M1) — Player-side grab box → walk to shelf → tap-to-place interaction.
- **`DeliveryPallet.cs`** (M1) — Spawns ProductBox prefabs at day start per the day's expected stock.
- **`CheckoutCounterInteractor.cs`** (M1) — Drives CheckoutStateMachine from the player side; deducts stock, adds cash.
- **`CustomerAgent.cs`** (M1) — NavMeshAgent-driven customer: Enter→Browse→PickItems→Queue→Checkout→Leave, driven by a CustomerProfileData.
- **`CustomerSpawner.cs`** (M1) — Spawns CustomerAgent instances at a fixed interval during open hours, capped at 3-4 concurrent.
- **`DayCycleManager.cs`** (M1) — Owns open/close state; triggers spawner, shows DaySummaryUI, deducts weekly bills, autosaves at day-end.

### UI layer

- **`PricingPanelUI.cs`** (M1) — Per-product row: icon, wholesale cost, price stepper, projected sell-through.
- **`CheckoutUI.cs`** (M1) — Scanned-item list, running total, numeric keypad, computed (not auto-applied) change.
- **`DaySummaryUI.cs`** (M1) — Revenue/costs/bills/net profit summary with a Continue-to-next-day button that triggers save.
- **`MainMenuUI.cs`** (M1) — New Game / Continue (grayed if no save) / Quit; checks SaveLoadService for an existing save.
- **`HUDController.cs`** (M1) — Persistent cash balance and day-number display.

## Key relationships at this stage

- **M1:** PricingModel reads flat `product.wholesaleCost`/baseline demand directly. CheckoutStateMachine and SaveLoadService are the only two Systems classes with I/O-adjacent responsibility (state transition, disk).

