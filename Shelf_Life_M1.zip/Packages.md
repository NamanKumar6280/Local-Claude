# Packages — Shelf Life (M1: Core Loop Vertical Slice)

`Packages/manifest.json` contents as of the end of M1. Packages are added only at the milestone that actually needs them — nothing is front-loaded.

| Package | Added | Purpose |
|---|---|---|
| `com.unity.render-pipelines.universal` | M1 | Universal Render Pipeline (URP), Mobile-tier preset |
| `com.unity.inputsystem` | M1 | New Input System — touch-first controls (virtual joystick + drag-look) |
| `com.unity.textmeshpro` | M1 | All UI text rendering |
| `com.unity.ai.navigation` | M1 | NavMesh baking + NavMeshAgent, needed for customer AI |
| `com.unity.ugui` | M1 | uGUI — simple screen-space panels |

**Not yet added (introduced by a later milestone):** `com.unity.addressables`, `com.unity.netcode.gameobjects`, `com.unity.transport`, `com.unity.services.relay`, `com.unity.services.lobby`, `com.unity.services.authentication`

