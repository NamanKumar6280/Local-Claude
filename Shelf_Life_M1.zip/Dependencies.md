# Dependencies — Shelf Life (M1: Core Loop Vertical Slice)

Third-party assets, external services, and libraries beyond the core Unity packages listed in `Packages.md`.

| Dependency | Type | Added | Notes |
|---|---|---|---|
| System.Text.Json | .NET/BCL | M1 | Used by SaveLoadService for JSON save/load; already IL2CPP-compatible, no extra package needed. |
| Kaggle Cloud Build Server notebook | External build infrastructure | M1 | Headless Unity Android build pipeline used to produce the .apk; not a Unity package, but a hard dependency of the project's build process. |

## Build infrastructure

The **Kaggle Cloud Build Server notebook** performs headless Unity Android builds of the `_Project/` tree, including a package-manifest dependency validator that checks every package referenced in `Packages/manifest.json` against the installed Editor's actual package list before compiling — this is why new Unity packages are only ever added at the milestone that genuinely needs them, to keep that validation surface minimal. It is not a Unity package itself, but a hard dependency of the project's build pipeline.

