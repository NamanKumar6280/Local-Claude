# Prefabs — Shelf Life (M1: Core Loop Vertical Slice)

| Prefab | Added | Description |
|---|---|---|
| `Player.prefab` | M1 | Player avatar with CharacterController + PlayerController. |
| `Shelf_Packaged.prefab` | M1 | Packaged-goods shelf unit with 6-8 ShelfSlot children. |
| `ProductBox.prefab` | M1 | Carryable box of stock, source for shelf stocking. |
| `CheckoutCounter.prefab` | M1 | Checkout station driving CheckoutCounterInteractor. |
| `Customer.prefab` | M1 | Base customer NPC using CustomerAgent. |
| `DeliveryPallet.prefab` | M1 | Daily stock delivery spawn point. |

**Total prefabs at this stage: 6**

