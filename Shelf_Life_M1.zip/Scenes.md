# Scenes — Shelf Life (M1: Core Loop Vertical Slice)

| Scene | Added | Purpose |
|---|---|---|
| `MainMenu.unity` | M1 | Single UGUI canvas: New Game / Continue / Quit. |
| `Shop.unity` | M1 | Core gameplay scene: baked NavMesh, one packaged-goods shelf, one delivery pallet, one checkout counter, player spawn, CustomerSpawner, DayCycleManager, baked lighting. |

## Build settings (scene list)

- **Scenes in Build:** `MainMenu` (index 0), `Shop` (index 1).
