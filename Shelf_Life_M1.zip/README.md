# SHELF LIFE — Project Overview
### Documentation snapshot as of Milestone M1 — Core Loop Vertical Slice

**Genre:** First-person business simulation  
**Platform:** Android (Unity 6, URP)  
**Multiplayer max:** N/A — single player through this milestone  
**Unity version:** 6000.0.35f1  
**Milestones completed:** 1 of 8 (M1)

---

## Vision

Start with an empty room and a lease. Everything that follows is built by hand, one shift at a time, then progressively delegated to employees (or handed to co-op teammates). Four pillars govern every system in the project: hands matter early, numbers are honest (no single profit lever), systems interlock rather than stack as sealed minigames, and multiplayer is cooperative role-division, not competition.

## Current milestone scope

**M1 — Core Loop Vertical Slice:** One shop, one shelf category (packaged goods), stocking, pricing, checkout, open/close, a single customer archetype, cash economy, manual/autosave. Single player only.

## What's playable as of this stage

- **M1 — Core Loop Vertical Slice:** One shop, one shelf category (packaged goods), stocking, pricing, checkout, open/close, a single customer archetype, cash economy, manual/autosave. Single player only.

## Document set

This zip contains the following companion documents, all describing the project as of the end of M1:

- `Architecture.md` — systems and their relationships
- `ScriptsIndex.md` — every script that exists at this stage, with a short description
- `Scenes.md` — all scenes and their purposes
- `Prefabs.md` — important prefabs
- `Packages.md` — Unity packages and versions in use at this stage
- `ProjectVersion.txt` — exact Unity version
- `Dependencies.md` — third-party assets, services, and libraries
- `CodingGuidelines.md` — naming conventions and architecture rules

## Save schema at this stage

| Milestone | Schema version | What changed |
|---|---|---|
| M1 | 1 | StoreStateData: schemaVersion, dayNumber, cashOnHand, stock, prices. |

## Roadmap (full 8-milestone plan)

| # | Milestone | New systems | Status |
|---|---|---|---|
| M1 | Core Loop Vertical Slice | One shop, one shelf category (packaged goods), stocking, pricing, checkout, open/close, a single customer archetype, cash economy, manual/autosave. | ✅ Complete (this snapshot) |
| M2 | Shelves & Economy Depth | Second shelf category (produce, requiring refrigeration), wholesale market fluctuation, bills cycle, customer archetypes as data profiles, store customization (paint/lighting/signage). | ⏳ Not yet built |
| M3 | Employees | Assistant → Cashier → Stock Manager hiring, skill/mood/experience model, employee AI sharing the customer utility-AI framework. | ⏳ Not yet built |
| M4 | Security & Theft | Shoplifting behavior, suspicion meter, confrontation flow, cameras/guards, reputation system. | ⏳ Not yet built |
| M5 | Delivery & the Town | Tablet ordering UI, delivery vehicle driving, modular town streaming (roads, one apartment tower, a handful of houses), COD cash-handling. | ⏳ Not yet built |
| M6 | Warehouse & Scale | Warehouse off-site storage, delivery driver employee AI, online ordering at scale (multiple simultaneous orders, delivery queue), store expansion (second location). | ⏳ Not yet built |
| M7 | LAN Multiplayer | StoreState authoritative replication, 2-3 player roles, role swapping, same-network play only. | ⏳ Not yet built |
| M8 | Cloud Multiplayer | Relay/matchmaking layer on top of M7's replication model, cloud save reconciliation. | ⏳ Not yet built |

---

*Source: generated from `Shelf_Life_FULL_GAME_Master_Spec.md` and `Shelf_Life_M1_Build_Spec.md` (plus all prior milestone specs) in the uploaded spec set.*
