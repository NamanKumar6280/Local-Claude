# Scripts Index — Shelf Life (M1: Core Loop Vertical Slice)

Every script that exists in the project as of the end of M1, grouped by folder/layer under `Assets/_Project/Scripts/`. "Added" is the milestone that introduced the file; "Modified" lists later milestones that changed it in place (Shelf Life never duplicates a script to extend it — existing files are modified, not forked).

## Data/

| Script | Description | Added | Modified |
|---|---|---|---|
| `CustomerProfileData.cs` | ScriptableObject archetype profile: patience, budget sensitivity, list adherence, browse-time and item-count ranges. | M1 | — |
| `ProductData.cs` | ScriptableObject defining a purchasable item: name, icon, category, wholesale cost, suggested price, shelf stack size. | M1 | — |
| `StoreStateData.cs` | Plain serializable save schema (schemaVersion, dayNumber, cashOnHand, stock, prices). | M1 | — |

## Systems/

| Script | Description | Added | Modified |
|---|---|---|---|
| `CheckoutStateMachine.cs` | Idle→Scanning→Payment→Complete state machine; scan, submit payment, change/bag-bonus math. | M1 | — |
| `DemandModel.cs` | Bounded random-walk wholesale price fluctuation, seeded for reproducible tests. | M1 | — |
| `InventorySystem.cs` | Pure C# stock ledger: Add/Remove/GetStock backed by a Dictionary<ProductData,int>. | M1 | — |
| `PricingModel.cs` | Pure functions for suggested margin and projected sell-through per product. | M1 | — |
| `SaveLoadService.cs` | System.Text.Json-based Save/Load with a schemaVersion migration switch (stubbed for v1). | M1 | — |

## Gameplay/

| Script | Description | Added | Modified |
|---|---|---|---|
| `CheckoutCounterInteractor.cs` | Drives CheckoutStateMachine from the player side; deducts stock, adds cash. | M1 | — |
| `CustomerAgent.cs` | NavMeshAgent-driven customer: Enter→Browse→PickItems→Queue→Checkout→Leave, driven by a CustomerProfileData. | M1 | — |
| `CustomerSpawner.cs` | Spawns CustomerAgent instances at a fixed interval during open hours, capped at 3-4 concurrent. | M1 | — |
| `DayCycleManager.cs` | Owns open/close state; triggers spawner, shows DaySummaryUI, deducts weekly bills, autosaves at day-end. | M1 | — |
| `DeliveryPallet.cs` | Spawns ProductBox prefabs at day start per the day's expected stock. | M1 | — |
| `PlayerController.cs` | CharacterController-based movement driven by PlayerControls.inputactions (Move/Look/Interact). | M1 | — |
| `ShelfSlot.cs` | Transform anchor holding one product + count; TryPlace fails cleanly on a mismatched product. | M1 | — |
| `ShelfStockingInteractor.cs` | Player-side grab box → walk to shelf → tap-to-place interaction. | M1 | — |

## UI/

| Script | Description | Added | Modified |
|---|---|---|---|
| `CheckoutUI.cs` | Scanned-item list, running total, numeric keypad, computed (not auto-applied) change. | M1 | — |
| `DaySummaryUI.cs` | Revenue/costs/bills/net profit summary with a Continue-to-next-day button that triggers save. | M1 | — |
| `HUDController.cs` | Persistent cash balance and day-number display. | M1 | — |
| `MainMenuUI.cs` | New Game / Continue (grayed if no save) / Quit; checks SaveLoadService for an existing save. | M1 | — |
| `PricingPanelUI.cs` | Per-product row: icon, wholesale cost, price stepper, projected sell-through. | M1 | — |

## Tests/

| Script | Description | Added | Modified |
|---|---|---|---|
| `CheckoutStateMachineTests.cs` | EditMode tests for CheckoutStateMachine. | M1 | — |
| `InventorySystemTests.cs` | EditMode tests for InventorySystem. | M1 | — |
| `PricingModelTests.cs` | EditMode tests for PricingModel. | M1 | — |
| `SaveLoadServiceTests.cs` | EditMode tests for SaveLoadService. | M1 | — |

**Total scripts at this stage: 25**

