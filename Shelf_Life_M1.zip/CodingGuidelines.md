# Coding Guidelines — Shelf Life (M1: Core Loop Vertical Slice)

Naming conventions and architecture rules that hold across the whole project. These accumulate — a rule introduced at one milestone applies to every milestone after it.

## Naming conventions

- PascalCase for all C# files and class names, matching standard Unity/.NET convention.
- ScriptableObject asset instances use descriptive, human-readable names (`CannedBeans.asset`), never a numbered scheme (`Product_01.asset`) — findability matters more than a fixed ordering, since these are content, not code.
- Save-data references to content (e.g. `productId`) use the ScriptableObject asset's stable name, never a runtime instance ID, since instance IDs are not stable across reimports.

## Architecture rules

- **Layering is strict:** Data (ScriptableObjects/save schemas) → Systems (pure C#) → Gameplay (MonoBehaviours) → UI (uGUI). Higher layers call into lower ones; lower layers never depend on higher ones.
- **Systems layer has zero Unity-engine dependencies** beyond basic types, so it's unit-testable via Unity's EditMode runner or plain `dotnet test` without an open Editor — every milestone ships EditMode tests for its new Systems-layer classes.
- **One codebase for player and AI actions:** any action an employee or an NPC performs (stocking a shelf, running a checkout, driving a delivery) calls the exact same System/interactor method the player uses. There is never a separate 'AI-only' implementation of an action a human player can also perform.
- **Data-driven content, not per-item code:** customer archetypes, demand events, products, town modules, and staff roles are all ScriptableObject assets consumed generically by their owning System. Adding new content is never a code change.
- **Forward-compatible field pattern:** a field or role needed by a *future* milestone (e.g. `spoilRateFallback`, `shopliftingChanceBase`, an inert `SecurityGuard` role) may be added early, but must stay completely unread by any current-milestone logic — this avoids ever reopening already-finished code purely to add a field.
- **Explicit schema versioning:** every save schema carries an integer `schemaVersion`; `SaveLoadService`'s migration path handles each version transition with an explicit case, never relying on implicit default-initialization.
- **Add a package only when it's load-bearing:** a new Unity package is added at the milestone that actually needs it, never front-loaded "just in case."
- **No stubs:** no placeholder text, `TODO`, or `NotImplementedException` may exist anywhere in `_Project/` at the end of any milestone's own scope.

## Milestone-specific notes accumulated so far

- **(M1)** PascalCase for all C# files and class names (Unity/.NET convention).
- **(M1)** ScriptableObject asset instances use descriptive names (e.g. `CannedBeans.asset`), never a numbered scheme (`Product_01.asset`) — findability over indexing.
- **(M1)** Systems layer (Data-consuming logic) is pure C# with zero Unity-engine dependencies beyond basic types, so it is unit-testable via the EditMode test runner or plain `dotnet test` without an open Editor.
- **(M1)** Gameplay layer is MonoBehaviours only; it calls into the Systems layer, never re-implements logic that belongs there.
- **(M1)** `productId` (used in save data) is the ScriptableObject asset's stable name, never an instance ID, to avoid save corruption across reimports.
- **(M1)** Every save schema has an explicit integer `schemaVersion`; `SaveLoadService` migrates via an explicit switch, never relies on default-initialization to "just work."
- **(M1)** Only add a Unity package at the milestone that actually needs it — no front-loading dependencies before they're load-bearing.
- **(M1)** No placeholder text, `TODO`, or `NotImplementedException` may exist anywhere in `_Project/` at the end of any milestone.

